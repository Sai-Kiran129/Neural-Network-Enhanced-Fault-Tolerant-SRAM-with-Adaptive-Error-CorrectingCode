import numpy as np
from tensorflow.keras.models import load_model

# Load the saved model
model = load_model('sram_model.h5')

# Function to convert binary string to an array
def binary_to_array(binary_string, length):
    binary_string = str(binary_string).zfill(length)  # Ensure correct length
    return np.array([int(bit) for bit in binary_string])

# Example inputs to test the model
test_corrupted_data = "00010000"  # Replace with your corrupted data (8 bits)
test_syndrome = "0101"            # Replace with your syndrome (4 bits)

# Preprocess the input to match the model's input format
input_vector = np.concatenate((
    binary_to_array(test_corrupted_data, 8),
    binary_to_array(test_syndrome, 4)
)).reshape(1, -1)  # Reshape to (1, 12) for a single prediction

# Predict using the model
predicted_output = model.predict(input_vector)

# Convert predicted output (probabilities) to binary
predicted_binary = (predicted_output > 0.5).astype(int).flatten()

# Display the result
print("Input Corrupted Data:", test_corrupted_data)
print("Input Syndrome:", test_syndrome)
print("Predicted Corrected Data:", "".join(map(str, predicted_binary)))
