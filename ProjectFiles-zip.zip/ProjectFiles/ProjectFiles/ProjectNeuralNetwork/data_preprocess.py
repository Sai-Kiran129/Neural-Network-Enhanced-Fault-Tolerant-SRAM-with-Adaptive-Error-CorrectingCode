import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split

# Function to convert integers to zero-padded binary strings
def int_to_binary_str(value, bit_length):
    return format(value, f'0{bit_length}b')

# Function to convert binary strings to numpy arrays
def binary_str_to_array(bin_str):
    return np.array([int(bit) for bit in bin_str])

# Load and preprocess the dataset
def load_and_preprocess_data(file_path):
    # Load the dataset
    df = pd.read_excel(file_path)

    # Ensure binary strings are properly padded
    df['Data Input'] = df['Data Input'].apply(lambda x: int_to_binary_str(x, 8))
    df['Syndrome'] = df['Syndrome'].apply(lambda x: int_to_binary_str(x, 4))
    df['Corrupted Data'] = df['Corrupted Data'].apply(lambda x: int_to_binary_str(x, 8))
    df['Corrected Data'] = df['Corrected Data'].apply(lambda x: int_to_binary_str(x, 8))

    # Validate lengths after correction
    assert all(df['Data Input'].apply(len) == 8), "Data Input still contains inconsistent lengths"
    assert all(df['Syndrome'].apply(len) == 4), "Syndrome still contains inconsistent lengths"
    assert all(df['Corrupted Data'].apply(len) == 8), "Corrupted Data still contains inconsistent lengths"
    assert all(df['Corrected Data'].apply(len) == 8), "Corrected Data still contains inconsistent lengths"

    # Convert columns to binary arrays
    corrupted_data = np.array([binary_str_to_array(cd) for cd in df["Corrupted Data"]])
    syndrome = np.array([binary_str_to_array(s) for s in df["Syndrome"]])
    corrected_data = np.array([binary_str_to_array(cd) for cd in df["Corrected Data"]])

    # Combine corrupted data and syndrome as inputs
    input_data = np.hstack((corrupted_data, syndrome))

    # Outputs remain as corrected data
    output_data = corrected_data

    # Split dataset into training (80%), validation (10%), and test (10%) sets
    X_train, X_temp, y_train, y_temp = train_test_split(input_data, output_data, test_size=0.2, random_state=42)
    X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, random_state=42)

    return X_train, X_val, X_test, y_train, y_val, y_test

# Example usage
file_path = "sram_dataset.xlsx"  # Replace with your actual file path
try:
    X_train, X_val, X_test, y_train, y_val, y_test = load_and_preprocess_data(file_path)

    # Print the sizes of the splits
    print("Training set:", X_train.shape, y_train.shape)
    print("Validation set:", X_val.shape, y_val.shape)
    print("Test set:", X_test.shape, y_test.shape)
except AssertionError as e:
    print("Error:", e)
