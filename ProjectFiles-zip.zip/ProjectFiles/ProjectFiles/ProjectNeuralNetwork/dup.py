import numpy as np
data_dir = "data"

# Load preprocessed data
X_train = np.load(f"{data_dir}/X_train.npy")
y_train = np.load(f"{data_dir}/y_train.npy")

# Check for uniqueness
print("Unique inputs in X_train:", np.unique(X_train, axis=0).shape[0])
print("Unique outputs in y_train:", np.unique(y_train, axis=0).shape[0])
